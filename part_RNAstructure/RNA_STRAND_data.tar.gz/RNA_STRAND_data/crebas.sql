/*==============================================================*/
/* DBMS name:      MySQL 4.0.14                                 */
/* Created on:     7/7/2004 12:25:38 PM                         */
/*==============================================================*/

drop database sstrand_2_0;
create database sstrand_2_0;
use sstrand_2_0;

#drop index PKNOT_BAND_REL_FK on BAND;
#drop index MOL_BIL_REL_FK on BULGE_AND_INTERNAL_LOOP;
#drop index MOL_EML_REL_FK on EXTERNAL_AND_MULTI_LOOP;
#drop index EL_EMLBR_REL_FK on EXTERNAL_AND_MULTI_LOOP_BRANCH;
#drop index HL_MOTIF_FK on HAIRPIN_LOOP;
#drop index MOL_HL_REL_FK on HAIRPIN_LOOP;
#drop index STEM_NCBP_REL_FK on NON_CANONICAL_BP;
#drop index PKNOT_PKLOOP_REL_FK on PKNOT_LOOP;
#drop index MOL_PKNOT_REL_FK on PSEUDOKNOT;
#drop index PKTYPE_PKNOT_REL_FK on PSEUDOKNOT;
#drop index BAND_STEM_REL_FK on STEM;
#drop index MOL_STEM_REL_FK on STEM;
#drop index RNATYPE_MOL_REL_FK on MOLECULE;
#drop index EXTSOURCE_MOL_REL_FK on MOLECULE;
-- drop table if exists BAND;
-- drop table if exists BULGE_AND_INTERNAL_LOOP;
-- drop table if exists CONNECTION;
-- drop table if exists EXTERNAL_AND_MULTI_LOOP;
-- drop table if exists EXTERNAL_AND_MULTI_LOOP_BRANCH;
-- drop table if exists HAIRPIN_LOOP;
-- drop table if exists HAIRPIN_MOTIF;
-- drop table if exists ELEM_STR_SEQUENCE_FEATURES;
-- drop table if exists MOLECULE;
-- drop table if exists RNA_TYPE;
-- drop table if exists EXTERNAL_SOURCE;
-- drop table if exists TMP_MOLECULE;
-- drop table if exists NON_CANONICAL_BP;
-- drop table if exists PKNOT_LOOP;
-- drop table if exists PSEUDOKNOT;
-- drop table if exists PSEUDOKNOT_TYPE;
-- drop table if exists STEM;

/*==============================================================*/
/* Table: BAND                                                  */
/*==============================================================*/
create table BAND
(
   BAND_ID                        int unsigned                   not null  AUTO_INCREMENT,
   PSEUDOKNOT_ID                  int unsigned                   not null,
   EXT_COORD_5P                   int,
   EXT_COORD_3P                   int,
   INT_COORD_5P                   int,
   INT_COORD_3P                   int,
   NUM_PAIRED_BASES               int,
   NUM_BAND_STEMS                 int,
   NUM_FREE_BASES_INSIDE          int,
   primary key (BAND_ID)
);

alter table BAND AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: PKNOT_BAND_REL_FK                                     */
/*==============================================================*/
create index PKNOT_BAND_REL_FK on BAND
(
   PSEUDOKNOT_ID
);

/*==============================================================*/
/* Table: BULGE_AND_INTERNAL_LOOP                               */
/*==============================================================*/
create table BULGE_AND_INTERNAL_LOOP
(
   BULGE_INTERNAL_ID              int unsigned                   not null  AUTO_INCREMENT,
   MOLECULE_ID                    varchar(20)                    not null,
   TYPE                           enum('BULGE','INTERNAL'),
   EXT_COORD_5P                   int,
   EXT_COORD_3P                   int,
   INT_COORD_5P                   int,
   INT_COORD_3P                   int,
   LENGTH_5P                      smallint,
   LENGTH_3P                      smallint,
   ASYM_AD                        float,
   ASYM_RA                        float,
   primary key (BULGE_INTERNAL_ID)
);

alter table BULGE_AND_INTERNAL_LOOP AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: MOL_BIL_REL_FK                                        */
/*==============================================================*/
create index MOL_BIL_REL_FK on BULGE_AND_INTERNAL_LOOP
(
   MOLECULE_ID
);

/*==============================================================*/
/* Table: CONNECTION                                            */
/*==============================================================*/
create table CONNECTION
(
   CONNECTION_ID                  int unsigned                   not null  AUTO_INCREMENT,
   EXT_ELEM_STR_ID                int unsigned,
   EXT_TYPE                       enum('STEM','HAIRPIN','INTERNAL','BULGE','MULTI', 'EXTERNAL','PSEUDOKNOT'),
   INT_ELEM_STR_ID                int unsigned,
   INT_TYPE                       enum('STEM','HAIRPIN','INTERNAL','BULGE','MULTI', 'EXTERNAL','PSEUDOKNOT'),
   primary key (CONNECTION_ID)
);

/*==============================================================*/
/* Table: EXTERNAL_AND_MULTI_LOOP                               */
/*==============================================================*/
create table EXTERNAL_AND_MULTI_LOOP
(
   EXT_MULTI_ID                   int unsigned                   not null  AUTO_INCREMENT,
   MOLECULE_ID                    varchar(20)                    not null,
   TYPE                           enum('EXTERNAL','MULTI')       not null,
   NUM_BRANCHES                   smallint,
   TOTAL_NUM_FREE_BASES           int,
   5P_COORDINATE                  int,
   3P_COORDINATE                  int,
   LEN_5P_END                     int,
   ASYM_AD_MAX                    float,
   ASYM_AD_MIN                    float,
   ASYM_AD_AVG                    float,
   ASYM_RA_MAX                    float,
   ASYM_RA_MIN                    float,
   ASYM_RA_AVG                    float,
   primary key (EXT_MULTI_ID)
);

alter table EXTERNAL_AND_MULTI_LOOP AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: MOL_EML_REL_FK                                        */
/*==============================================================*/
create index MOL_EML_REL_FK on EXTERNAL_AND_MULTI_LOOP
(
   MOLECULE_ID
);

/*==============================================================*/
/* Table: EXTERNAL_AND_MULTI_LOOP_BRANCH                        */
/*==============================================================*/
create table EXTERNAL_AND_MULTI_LOOP_BRANCH
(
   EXT_MULTI_BR_ID                 int unsigned                   not null  AUTO_INCREMENT,
   EXT_MULTI_ID                   int unsigned                   not null,
   5P_COORDINATE                  int,
   3P_COORDINATE                  int,
   LEN_3P_END                     int,
   primary key (EXT_MULTI_BR_ID)
);

alter table EXTERNAL_AND_MULTI_LOOP_BRANCH AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: EL_EMLBR_REL_FK                                       */
/*==============================================================*/
create index EL_EMLBR_REL_FK on EXTERNAL_AND_MULTI_LOOP_BRANCH
(
   EXT_MULTI_ID
);

/*==============================================================*/
/* Table: HAIRPIN_LOOP                                          */
/*==============================================================*/
create table HAIRPIN_LOOP
(
   HAIRPIN_LOOP_ID                int unsigned                   not null  AUTO_INCREMENT,
   HAIRPIN_MOTIF_ID               tinyint,
   MOLECULE_ID                    varchar(20)                    not null,
   5P_COORDINATE                  int,
   3P_COORDINATE                  int,
   LENGTH                         int,
   SEQUENCE                       text,
   primary key (HAIRPIN_LOOP_ID)
);

alter table HAIRPIN_LOOP AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: HL_MOTIF_FK                                           */
/*==============================================================*/
create index HL_MOTIF_FK on HAIRPIN_LOOP
(
   HAIRPIN_MOTIF_ID
);

/*==============================================================*/
/* Index: MOL_HL_REL_FK                                         */
/*==============================================================*/
create index MOL_HL_REL_FK on HAIRPIN_LOOP
(
   MOLECULE_ID
);

/*==============================================================*/
/* Table: HAIRPIN_MOTIF                                         */
/*==============================================================*/
create table HAIRPIN_MOTIF
(
   HAIRPIN_MOTIF_ID               tinyint                   not null,
   MOTIF                          varchar(200),
   primary key (HAIRPIN_MOTIF_ID)
);

insert into HAIRPIN_MOTIF
  values
    (1,'GNRA'),
    (2,'GNYA'),
    (3,'UUCG');


/*==============================================================*/
/* Table: ELEM_STR_SEQUENCE_FEATURES                            */
/*==============================================================*/
create table ELEM_STR_SEQUENCE_FEATURES
(
   ELEM_STR_ID                    int unsigned,
   ELEM_STR_TYPE                  enum('STEM','HAIRPIN','INTERNAL','BULGE','MULTI','EXTERNAL','BAND_STEM',
                                       'FB_WITHIN_BAND','ALL_STEMS','ALL_HAIRPINS','ALL_INTERNALS',
                                       'ALL_BULGES','ALL_MULTIS','ALL_EXTERNAL','ALL_BAND_STEMS',
                                       'ALL_FB_WITHIN_BANDS'),
   NUM_A                          int,
   NUM_C                          int,
   NUM_G                          int,
   NUM_U                          int,
   NUM_OTHER_FREE_BASES           int,
   NUM_AU                         int,
   NUM_CG                         int,
   NUM_GU                         int,
   NUM_NON_CANONICAL              int,
   NUM_AA                         int, 
   NUM_AC                         int,
   NUM_AG                         int,
   NUM_CC                         int,
   NUM_CU                         int,
   NUM_GG                         int,
   NUM_UU                         int,
   NUM_OTHER_BASE_PAIRS           int,

   PER_A                          float,
   PER_C                          float,
   PER_G                          float,
   PER_U                          float,
   PER_OTHER_FREE_BASES           float,
   PER_AU                         float,
   PER_CG                         float,
   PER_GU                         float,
   PER_NON_CANONICAL              float,
   PER_AA                         float,
   PER_AC                         float,
   PER_AG                         float,
   PER_CC                         float,
   PER_CU                         float,
   PER_GG                         float,
   PER_UU                         float,
   PER_OTHER_BASE_PAIRS           float
);

/*==============================================================*/
/* Table: MOLECULE                                              */
/*==============================================================*/
create table MOLECULE
(
   MOLECULE_ID                    varchar(20)                    not null,
   SUBMITTER_NAME                 varchar(100),
   SUBMITTER_EMAIL		          varchar(100),
   SUBMISSION_DATE_TIME           datetime,
   MOLECULE_NAME                  varchar(100),
   RNA_TYPE_ID                    tinyint,
   ORGANISM                       varchar(200),
   EXTERNAL_SOURCE_ID             tinyint,
   EXTERNAL_ID                    varchar(50),
   EXTERNAL_ID_LINK               text,
   SEQUENCE                       text,
   ABSTRACT_SHAPE_1               text,
   ABSTRACT_SHAPE_3               text,
   ABSTRACT_SHAPE_5               text,
   REFERENCE                      text,
   EXPERIMENTALLY_PROVEN          enum('Y','N'),
   METHOD                         text,
   NUM_MOLECULES                  smallint,
   FRAGMENT                       enum('Y','N'),
   COMMENTS                       text,
   VISIBLE                        enum('Y','N'),
   LINK_IF_NOT_VISIBLE            text,
   VALIDATOR_NAME                 varchar(100),
   VALIDATION_DATE_TIME           datetime,
   CT_FILE                        varchar(200),
   
   LENGTH                         int,
   TOTAL_NUM_ARCS_TO_REMOVE       int,
   TOTAL_NUM_BANDS_TO_REMOVE      int,
   TOTAL_UNIQUE_REMOVE            enum('Y','N'),

   NUM_DOMAINS                    int,
   NUM_STEMS                      int,
   NUM_BASE_PAIRS_IN_STEMS        int,
   NUM_HAIRPIN_LOOPS              int,
   NUM_BULGES                     int,
   NUM_INTERNAL_LOOPS             int,
   NUM_MULTI_LOOPS                int,
   NUM_PSEUDOKNOTS                int,
   NUM_BANDS                      int,
   NUM_BASE_PAIRS_IN_BANDS        int,

   LEN_STEM_MAX                   float,
   LEN_STEM_MIN                   float,
   LEN_STEM_AVG                   float,
   LEN_HAIRPIN_MAX                float,
   LEN_HAIRPIN_MIN                float,
   LEN_HAIRPIN_AVG                float,
   LEN_BULGE_MAX                  float,
   LEN_BULGE_MIN                  float,
   LEN_BULGE_AVG                  float,
   LEN_INT_LOOP_MAX               float,
   LEN_INT_LOOP_MIN               float,
   LEN_INT_LOOP_AVG               float,
   LEN_MULTI_LOOP_MAX             float,
   LEN_MULTI_LOOP_MIN             float,
   LEN_MULTI_LOOP_AVG             float,
   LEN_BAND_MAX                   float,
   LEN_BAND_MIN                   float,
   LEN_BAND_AVG                   float,

   primary key (MOLECULE_ID)
);

/*alter table MOLECULE AUTO_INCREMENT = 1001;*/

/*==============================================================*/
/* Index: RNATYPE_MOL_REL_FK                                      */
/*==============================================================*/
create index RNATYPE_MOL_REL_FK on MOLECULE
(
   RNA_TYPE_ID
);


/*==============================================================*/
/* Index: EXTSOURCE_MOL_REL_FK                                      */
/*==============================================================*/
create index EXTSOURCE_MOL_REL_FK on MOLECULE
(
   EXTERNAL_SOURCE_ID
);


/*==============================================================*/
/* Table: RNA_TYPE                                              */
/*==============================================================*/
create table RNA_TYPE
(
   RNA_TYPE_ID                    tinyint                      not null  AUTO_INCREMENT,
   RNA_TYPE_SHDESC                varchar(20),
   RNA_TYPE_DESCRIPTION           varchar(50),
   primary key (RNA_TYPE_ID)
);

insert into RNA_TYPE
    (RNA_TYPE_SHDESC, RNA_TYPE_DESCRIPTION)
  values        
    ('aRNA', 'Antisense RNA'),
    ('RNAIII', 'RNAIII'),
    ('Cis-reg. element', 'Cis-regulatory element'),  
    ('GI Intron', 'Group I Intron'),
    ('GII Intron', 'Group II Intron'),
    ('IRES', 'Internal Ribosome Entry Site'),
    ('mRNA', 'Messenger RNA'),
    ('microRNA', 'Micro RNA'),    
    ('Response Element', 'Response Element'),
    ('5S rRNA', '5S Ribosomal RNA'),
    ('16S rRNA', '16S Ribosomal RNA'),
    ('23S rRNA', '23S Ribosomal RNA'),
    ('70S Ribosome', '70S Ribosome'),
    ('Other rRNA', 'Other Ribosomal RNA'),
    ('Riboswitch', 'Riboswitch'),
    ('Ham. Ribozyme', 'Hammerhead Ribozyme'),
    ('Hairp. Ribozyme', 'Hairpin Ribozyme'),
    ('HDV Ribozyme', 'Hepatitis Delta Virus Ribozyme'),
    ('Other Ribozyme', 'Other Ribozyme'),
    ('RNase E 5 UTR', 'RNase E 5 UTR'),
    ('RNase P RNA', 'Ribonuclease P RNA'),
    ('RNase MRP RNA', 'Ribonuclease MRP RNA'),
    ('Small RNA', 'Small RNA'),    
    ('snRNA', 'Small nuclear RNA'),
    ('snoRNA', 'Small nucleolar RNA'),
    ('SRP RNA', 'Signal Recognition Particle RNA'),
    ('Vert. Telo. RNA', 'Vertebrate Telomerase RNA'),
    ('Cili. Telo. RNA', 'Ciliate Telomerase RNA'),
    ('tRNA', 'Transfer RNA'),
    ('tmRNA', 'Transfer Messenger RNA'),
    ('Viral & Phage', 'Viral & Phage RNA'),
    ('Y RNA', 'Y RNA'),
    ('7SK RNA', '7SK RNA'),
    ('Synthetic RNA', 'Synthetic RNA'),
    ('Other RNA', 'Other RNA'),
    ('Unknown', 'Unknown');

/*    ('RNA Aptamer'),
    ('Transcription-Related RNA'),
    ('Vault RNA'),  
*/
            
/*==============================================================*/
/* Table: EXTERNAL_SOURCE                                       */
/*==============================================================*/
create table EXTERNAL_SOURCE
(
   EXTERNAL_SOURCE_ID                    tinyint                      not null  AUTO_INCREMENT,
   EXTERNAL_SOURCE_DESCRIPTION           varchar(100),
   EXTERNAL_SOURCE_LINK                  varchar(200),
   primary key (EXTERNAL_SOURCE_ID)
);


insert into EXTERNAL_SOURCE
    (EXTERNAL_SOURCE_DESCRIPTION, EXTERNAL_SOURCE_LINK)
  values
    ('Gutell Lab CRW Site', 'http://www.rna.ccbb.utexas.edu/'),
    ('RCSB Protein Data Bank', 'http://www.rcsb.org/pdb/'),
    ('Nucleic Acid Database', 'http://ndbserver.rutgers.edu/'),
    ('Rfam Database', 'http://www.sanger.ac.uk/Software/Rfam/index.shtml'),    
    ('RNase P Database', 'http://jwbrown.mbio.ncsu.edu/RNaseP/home.html'),
    ('Sprinzl tRNA Database', 'http://www.uni-bayreuth.de/departments/biochemie/sprinzl/trna/'),
    ('SRP Database', 'http://rnp.uthct.edu/rnp/SRPDB/SRPDB.html'),
    ('tmRNA Database', 'http://rnp.uthct.edu/rnp/tmRDB/tmRDB.html');
    
/*    ('SRPDB - Signal Recognition Particle DB', 'http://psyche.uthct.edu/dbs/SRPDB/SRPDB.html'),*/

/*==============================================================*/
/* Table: MOLECULE                                              */
/*==============================================================*/
create table TMP_MOLECULE
(
   TMP_MOLECULE_ID                varchar(20)                    not null,
   SUBMITTER_NAME                 varchar(100),
   SUBMITTER_EMAIL                varchar(100),
   SUBMISSION_DATE_TIME           datetime,
   MOLECULE_NAME                  varchar(100),
   TYPE                           varchar(100),
   ORGANISM                       varchar(200),
   EXTERNAL_SOURCE                text,
   EXTERNAL_ID                    varchar(50),
   REFERENCE                      text,
   EXPERIMENTALLY_PROVEN          enum('Y','N'),
   METHOD                         text,
   NUM_MOLECULES                  smallint,
   FRAGMENT                       enum('Y','N'),
   COMMENTS                       text,
   CT_FILE                     varchar(200),
   primary key (TMP_MOLECULE_ID)
);
                                                                                                                                                             
/*alter table TMP_MOLECULE AUTO_INCREMENT = 1001;*/


/*==============================================================*/
/* Index: RNATYPE_TMPMOL_REL_FK                                      */
/*==============================================================*/
--create index RNATYPE_TMPMOL_REL_FK on TMP_MOLECULE
--(
--   RNA_TYPE_ID
--);


/*==============================================================*/
/* Table: NON_CANONICAL_BP                                      */
/*==============================================================*/
create table NON_CANONICAL_BP
(
   NON_CANONICAL_BP_ID            int unsigned                   not null  AUTO_INCREMENT,
   STEM_ID                        int unsigned,
   5P_BASE_1                      char(1),
   5P_BASE_2                      char(1),
   5P_NC_BASE_3                   char(1),
   5P_BASE_4                      char(1),
   5P_BASE_5                      char(1),
   3P_BASE_1                      char(1),
   3P_BASE_2                      char(1),
   3P_NC_BASE_3                   char(1),
   3P_BASE_4                      char(1),
   3P_BASE_5                      char(1),
   PAIR_1_CONNECTED               enum('Y','N'),
   PAIR_2_CONNECTED               enum('Y','N'),
   PAIR_4_CONNECTED               enum('Y','N'),
   PAIR_5_CONNECTED               enum('Y','N'),
   primary key (NON_CANONICAL_BP_ID)
);

alter table NON_CANONICAL_BP AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: STEM_NCBP_REL_FK                                      */
/*==============================================================*/
create index STEM_NCBP_REL_FK on NON_CANONICAL_BP
(
   STEM_ID
);

/*==============================================================*/
/* Table: PKNOT_LOOP                                            */
/*==============================================================*/
create table PKNOT_LOOP
(
   PKNOT_LOOP_ID                  int unsigned                   not null  AUTO_INCREMENT,
   PSEUDOKNOT_ID                  int unsigned                   not null,
   LENGTH                         int,
   5P_COORDINATE                  int,
   3P_COORDINATE                  int,
   primary key (PKNOT_LOOP_ID)
);

alter table PKNOT_LOOP AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: PKNOT_PKLOOP_REL_FK                                   */
/*==============================================================*/
create index PKNOT_PKLOOP_REL_FK on PKNOT_LOOP
(
   PSEUDOKNOT_ID
);

/*==============================================================*/
/* Table: PSEUDOKNOT                                            */
/*==============================================================*/
create table PSEUDOKNOT
(
   PSEUDOKNOT_ID                  int unsigned                   not null  AUTO_INCREMENT,
   MOLECULE_ID                    varchar(20)                    not null,
   5P_COORDINATE                  int,
   3P_COORDINATE                  int,
   NUM_CHILDREN                   int,
   NUM_UNBANDS                    smallint,
   NUM_INBANDS                    smallint,
   NUM_UNPAIRED_BASES             int,
   NUM_BANDS                      int,
   NUM_ARCS_TO_REMOVE             int,
   NUM_BANDS_TO_REMOVE            int,
   UNIQUE_REMOVE                  enum('Y','N'),
   PKTYPE_ID                      tinyint,
   TYPE_SPECIAL                   enum('Y','N'),
   TYPE_SIMPLE_OR_COMPLEX         enum('S','C'),
   primary key (PSEUDOKNOT_ID)
);

alter table PSEUDOKNOT AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: MOL_PKNOT_REL_FK                                      */
/*==============================================================*/
create index MOL_PKNOT_REL_FK on PSEUDOKNOT
(
   MOLECULE_ID
);

/*==============================================================*/
/* Index: PKTYPE_PKNOT_REL_FK                                      */
/*==============================================================*/
create index PKTYPE_PKNOT_REL_FK on PSEUDOKNOT
(
   PKTYPE_ID
);

/*==============================================================*/
/* Table: PSEUDOKNOT_TYPE                                       */
/*==============================================================*/
create table PSEUDOKNOT_TYPE
(
   PKTYPE_ID                      tinyint   not null,
   TYPE_DESCRIPTION               text,
   primary key (PKTYPE_ID)
);

insert into PSEUDOKNOT_TYPE
  values
    (1, 'E-H: connecting external loop and hairpin loop'),
    (2, 'E-I: connecting external loop and internal loop'),
    (3, 'E-M: connecting external loop and multi-loop'),
    (4, 'H-H: connecting two hairpin loops'),
    (5, 'H-I: connecting hairpin loop and internal loop'),
    (6, 'H-M: connecting hairpin loop and multi-loop'),
    (7, 'I-I: connecting two internal loops'),
    (8, 'I-M: connecting internal loop and multi-loop'),
    (9, 'M-M: connecting two multi-loops'),
    (10, 'unclassified');

/*==============================================================*/
/* Table: STEM                                                  */
/*==============================================================*/
create table STEM
(
   STEM_ID                        int unsigned                   not null  AUTO_INCREMENT,
   BAND_ID                        int unsigned ,
   MOLECULE_ID                    varchar(20),
   EXT_COORD_5P                   int,
   EXT_COORD_3P                   int,
   INT_COORD_5P                   int,
   INT_COORD_3P                   int,
   LENGTH                         int,
   ESTIMATED_FREE_ENERGY          float(5),
   primary key (STEM_ID)
);

alter table STEM AUTO_INCREMENT = 100;

/*==============================================================*/
/* Index: MOL_STEM_REL_FK                                       */
/*==============================================================*/
create index MOL_STEM_REL_FK on STEM
(
   MOLECULE_ID
);

/*==============================================================*/
/* Index: BAND_STEM_REL_FK                                      */
/*==============================================================*/
create index BAND_STEM_REL_FK on STEM
(
   BAND_ID
);

/*==============================================================*/
/* Insert dumb values in the AUTO_INCREMENT tables              */
/*==============================================================*/

insert into BAND () values ();
insert into BULGE_AND_INTERNAL_LOOP () values ();
insert into EXTERNAL_AND_MULTI_LOOP () values ();
insert into EXTERNAL_AND_MULTI_LOOP_BRANCH () values ();
insert into HAIRPIN_LOOP () values ();
insert into NON_CANONICAL_BP () values ();
insert into PKNOT_LOOP () values ();
insert into PSEUDOKNOT () values ();
insert into STEM () values ();


-- After I insert some structures everywhere, erase the dumb values */
--delete from BAND where BAND_ID = 100;*/
--delete from BULGE_AND_INTERNAL_LOOP where BULGE_INTERNAL_ID = 100;*/
--delete from EXTERNAL_AND_MULTI_LOOP where EXT_MULTI_ID = 100;*/
#delete from EXTERNAL_AND_MULTI_LOOP_BRANCH where EXT_MULTI_BR_ID = 100;*/
#delete from HAIRPIN_LOOP where HAIRPIN_LOOP_ID = 100;*/
#delete from NON_CANONICAL_BP where NON_CANONICAL_BP_ID = 100;*/
#delete from PKNOT_LOOP where PKNOT_LOOP_ID = 100;*/
#delete from PSEUDOKNOT where PSEUDOKNOT_ID = 100;*/
#delete from STEM where STEM_ID = 100;*/
  
#==============================================================*/
# Create a new table, in which we keep the unique ID's for     */
# each entry, so that, if we need to repopulate the database,  */ 
# the unique ID's are unchanged                                */
#==============================================================*/

#create table UNIQUE_IDS
#(
#    MOLECULE_ID                    varchar(20),
#    MOLECULE_DESC                  varchar(200)
#);


